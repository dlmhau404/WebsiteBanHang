<div id="sidebar" class="fl-left">
    <ul id="list-cat">
        <li>
            <a href="?mod=users&action=reset" title="">Đổi mật khẩu</a>
        </li>
        <li>
            <a href="?mod=users&action=update" title="">Cập nhật thông tin</a>
        </li>
        <li>
            <a href="?mod=users&controller=team" title="">Nhóm quản trị</a>
        </li>
        <li>
            <a href="?mod=users&action=logout" title="">Thoát</a>
        </li>
    </ul>
</div>