<div id="footer-wp">
    <div class="wp-inner">
        <p id="copyright">2022 © Admin by My Motobike</p>
    </div>
</div>
</div>
</div>
</body>

</html>