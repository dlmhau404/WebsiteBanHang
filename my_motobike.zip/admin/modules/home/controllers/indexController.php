<?php

function construct()
{
    load_model('index');
}

function indexAction()
{
    $data['num_rows_delivering'] = get_num_rows("tbl_transaction", "`status` = '1'");
    $data['num_rows_waiting'] = get_num_rows("tbl_transaction", "`status` = '0'");
    $data['num_rows_delivered'] = get_num_rows("tbl_transaction", "`status` = '2'");
    $data['total_sales'] = get_total_sales();
    load_view('index', $data);
}

function addAction()
{
}

function editAction()
{
}