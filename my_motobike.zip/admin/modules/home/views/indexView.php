<?php
get_header();

?>

<div id="main-content-wp" class="list-post-page">
    <div class="wrap clearfix">
        <?php
        get_sidebar();
        ?>
        <div id="content" class="fl-right">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
                            <div class="card-header">ĐƠN HÀNG ĐANG CHỜ</div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $num_rows_waiting; ?></h5>
                                <p class="card-text">Đơn hàng đang chờ để xử lý</p>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
                            <div class="card-header">ĐANG HÀNG ĐÃ CHUYỂN</div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $num_rows_delivered; ?></h5>
                                <p class="card-text">Đơn hàng giao dịch thành công</p>
                            </div>
                        </div>
                    </div>

                    <div class="col">
                        <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
                            <div class="card-header">ĐƠN HÀNG ĐANG CHUYỂN</div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $num_rows_delivering; ?></h5>
                                <p class="card-text">Đơn hàng đang vận chuyển</p>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="card text-white bg-dark mb-3" style="max-width: 18rem;">
                            <div class="card-header">DOANH SỐ</div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo currency_format($total_sales) ?></h5>
                                <p class="card-text">Daonh số hệ thống</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
get_footer();

?>