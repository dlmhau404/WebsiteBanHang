<?php
function get_num_rows($table, $where = '')
{
    if (empty($where)) {
        $result = db_num_rows("SELECT * FROM `{$table}`");
        return $result;
    } else {
        $result = db_num_rows("SELECT * FROM `{$table}` WHERE {$where}");
        return $result;
    }
}
//Lấy tổng doanh số
function get_total_sales()
{
    $item = db_fetch_row("select sum(`sub_total`) total_sales from `tbl_order`");
    return $item['total_sales'];
}