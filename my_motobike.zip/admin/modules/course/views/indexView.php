<?php
get_header();
?>
<div id="content">
    <h1>Khóa học</h1>
</div>
<?php
get_footer();
?>