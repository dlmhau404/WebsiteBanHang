<?php
function construct()
{
}

function indexAction()
{
    load_view('teamIndex');
}